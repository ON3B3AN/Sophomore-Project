package Controller;

import com.jfoenix.controls.JFXButton;
import java.io.IOException;
import java.net.URL;
import java.time.LocalDateTime;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.MenuItem;
import javafx.scene.image.Image;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;


public class EmployeeAcctController implements Initializable {
  
    @FXML
    private AnchorPane empAcctPane;
    
    @FXML
    private JFXButton settingsBtn;
    
    @FXML
    private JFXButton clockBtn;
    
    @FXML
    private JFXButton logoutBtn;
    
    @FXML
    private MenuItem empInfoMI;
    
    @FXML
    private MenuItem changeEmpInfoMI;
    
    @FXML
    void handleChangeEmpInfoMISelected(ActionEvent event) {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/View/ChangeEmpInfo.fxml"));
        
        try {
            Node n = (Node)loader.load();
            AnchorPane.setTopAnchor(n, 0.0);
            AnchorPane.setRightAnchor(n, 0.0);
            AnchorPane.setLeftAnchor(n, 0.0);
            AnchorPane.setBottomAnchor(n, 0.0);
            empAcctPane.getChildren().setAll(n);
        } 
        catch (IOException e){
            System.out.println(e.getMessage());
        }
    }
    
    @FXML
    void handleEmpInfoMISelected(ActionEvent event) {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/View/EmployeeInfo.fxml"));
        
        try {
            Node n = (Node)loader.load();
            AnchorPane.setTopAnchor(n, 0.0);
            AnchorPane.setRightAnchor(n, 0.0);
            AnchorPane.setLeftAnchor(n, 0.0);
            AnchorPane.setBottomAnchor(n, 0.0);
            empAcctPane.getChildren().setAll(n);
        } 
        catch (IOException e){
            System.out.println(e.getMessage());
        }
    }
    
    @FXML
    void handleSettingsBtnClicked(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/View/Settings.fxml"));
        
        try {
            Node n = (Node)loader.load();
            AnchorPane.setTopAnchor(n, 0.0);
            AnchorPane.setRightAnchor(n, 0.0);
            AnchorPane.setLeftAnchor(n, 0.0);
            AnchorPane.setBottomAnchor(n, 0.0);
            empAcctPane.getChildren().setAll(n);
        } 
        catch (IOException e){
            System.out.println(e.getMessage());
        }
    }
    
    @FXML
    void handleLogoutBtnClicked(ActionEvent event) throws IOException {
            Stage lastStage = (Stage) logoutBtn.getScene().getWindow();
            lastStage.close();
            Stage stage = new Stage();
            Pane root = FXMLLoader.load(getClass().getResource("/View/BankLogin.fxml")); 
            stage.getIcons().add(new Image("/View/path_logo.png"));
            stage.setTitle("Trail Bank");
            stage.setScene(new Scene(root, 600, 400));
            stage.setResizable(false);
            stage.sizeToScene();
            stage.show();  
    }
    
    int count = 0;
    
    @FXML
    public void handleClockBtnClicked(ActionEvent event) {
        
        LocalDateTime ldt = LocalDateTime.now();
        count =+ count%2;
        
        if(count == 0) {
            System.out.println("Clock-In: "+ldt);
            clockBtn.setText("Clock-Out");
            clockBtn.setStyle("-fx-background-color: #0066CC;");
        }
        else {
            System.out.println("Clock-Out: "+ldt);
            clockBtn.setText("Clock-In");
            clockBtn.setStyle("-fx-background-color: #7F007F;");
        }
        count++;
    }
    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
