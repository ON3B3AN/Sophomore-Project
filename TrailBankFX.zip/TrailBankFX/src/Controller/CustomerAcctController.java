package Controller;

import com.jfoenix.controls.JFXButton;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.MenuItem;
import javafx.scene.image.Image;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;


public class CustomerAcctController implements Initializable {

    
    @FXML
    private MenuItem createBankAcctMI;
    
    @FXML
    private MenuItem depositMI;
    
    @FXML
    private MenuItem moneyMarketMI;
    
    @FXML
    private AnchorPane custAcctPane;
    
    @FXML
    private JFXButton logoutBtn;
        
    @FXML
    private JFXButton settingsBtn;
    
    @FXML
    private MenuItem createCCMI;

    @FXML
    private MenuItem savingsMI;

    @FXML
    private MenuItem intCheckingMI;

    @FXML
    private MenuItem closeMI;

    @FXML
    private MenuItem checkingMI;

    @FXML
    private MenuItem createLoan;

    @FXML
    private MenuItem withdrawMI;

    @FXML
    private MenuItem certDepositMI;

    @FXML
    private MenuItem displayCCMI;

    @FXML
    private MenuItem displayLoan;

    @FXML
    private MenuItem retireMI;
    

    @FXML
    public void handleCloseMISelected(ActionEvent event) {
        //
    }
    
     @FXML
    public void handleCheckingMISelected(ActionEvent event) {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/View/BankAcctShow.fxml"));
        
        try {
            Node n = (Node)loader.load();
            AnchorPane.setTopAnchor(n, 0.0);
            AnchorPane.setRightAnchor(n, 0.0);
            AnchorPane.setLeftAnchor(n, 0.0);
            AnchorPane.setBottomAnchor(n, 0.0);
            custAcctPane.getChildren().setAll(n);
        } 
        catch (IOException e){
            System.out.println(e.getMessage());
        }
    }

    @FXML
    public void handleSavingsMISelected(ActionEvent event) {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/View/BankAcctShow.fxml"));
        
        try {
            Node n = (Node)loader.load();
            AnchorPane.setTopAnchor(n, 0.0);
            AnchorPane.setRightAnchor(n, 0.0);
            AnchorPane.setLeftAnchor(n, 0.0);
            AnchorPane.setBottomAnchor(n, 0.0);
            custAcctPane.getChildren().setAll(n);
        } 
        catch (IOException e){
            System.out.println(e.getMessage());
        }
    }

    @FXML
    public void handleIntCheckingMISelected(ActionEvent event) {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/View/BankAcctShow.fxml"));
        
        try {
            Node n = (Node)loader.load();
            AnchorPane.setTopAnchor(n, 0.0);
            AnchorPane.setRightAnchor(n, 0.0);
            AnchorPane.setLeftAnchor(n, 0.0);
            AnchorPane.setBottomAnchor(n, 0.0);
            custAcctPane.getChildren().setAll(n);
        } 
        catch (IOException e){
            System.out.println(e.getMessage());
        }
    }

    @FXML
    public void handleCertDepositMISelected(ActionEvent event) {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/View/BankAcctShow.fxml"));
        
        try {
            Node n = (Node)loader.load();
            AnchorPane.setTopAnchor(n, 0.0);
            AnchorPane.setRightAnchor(n, 0.0);
            AnchorPane.setLeftAnchor(n, 0.0);
            AnchorPane.setBottomAnchor(n, 0.0);
            custAcctPane.getChildren().setAll(n);
        } 
        catch (IOException e){
            System.out.println(e.getMessage());
        }
    }

    @FXML
    public void handleMoneyMarketMISelected(ActionEvent event) {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/View/BankAcctShow.fxml"));
        
        try {
            Node n = (Node)loader.load();
            AnchorPane.setTopAnchor(n, 0.0);
            AnchorPane.setRightAnchor(n, 0.0);
            AnchorPane.setLeftAnchor(n, 0.0);
            AnchorPane.setBottomAnchor(n, 0.0);
            custAcctPane.getChildren().setAll(n);
        } 
        catch (IOException e){
            System.out.println(e.getMessage());
        }
    }

    @FXML
    public void handleRetireMISelected(ActionEvent event) {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/View/BankAcctShow.fxml"));
        
        try {
            Node n = (Node)loader.load();
            AnchorPane.setTopAnchor(n, 0.0);
            AnchorPane.setRightAnchor(n, 0.0);
            AnchorPane.setLeftAnchor(n, 0.0);
            AnchorPane.setBottomAnchor(n, 0.0);
            custAcctPane.getChildren().setAll(n);
        } 
        catch (IOException e){
            System.out.println(e.getMessage());
        }
    }
    
    @FXML
    public void handleCreateBankAcctMISelected(ActionEvent event) {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/View/CreateBankAcct.fxml"));
        
        try {
            Node n = (Node)loader.load();
            AnchorPane.setTopAnchor(n, 0.0);
            AnchorPane.setRightAnchor(n, 0.0);
            AnchorPane.setLeftAnchor(n, 0.0);
            AnchorPane.setBottomAnchor(n, 0.0);
            custAcctPane.getChildren().setAll(n);
        } 
        catch (IOException e){
            System.out.println(e.getMessage());
        }
    }

    @FXML
    public void handleWithdrawMISelected(ActionEvent event) {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/View/Withdraw.fxml"));
        
        try {
            Node n = (Node)loader.load();
            AnchorPane.setTopAnchor(n, 0.0);
            AnchorPane.setRightAnchor(n, 0.0);
            AnchorPane.setLeftAnchor(n, 0.0);
            AnchorPane.setBottomAnchor(n, 0.0);
            custAcctPane.getChildren().setAll(n);
        } 
        catch (IOException e){
            System.out.println(e.getMessage());
        }
    }

    @FXML
    public void handleDepositMISelected(ActionEvent event) {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/View/Deposit.fxml"));
        
        try {
            Node n = (Node)loader.load();
            AnchorPane.setTopAnchor(n, 0.0);
            AnchorPane.setRightAnchor(n, 0.0);
            AnchorPane.setLeftAnchor(n, 0.0);
            AnchorPane.setBottomAnchor(n, 0.0);
            custAcctPane.getChildren().setAll(n);
        } 
        catch (IOException e){
            System.out.println(e.getMessage());
        }
    }

    @FXML
    public void handleDisplayCCMISelected(ActionEvent event) {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/View/CreditCards.fxml"));
        
        try {
            Node n = (Node)loader.load();
            AnchorPane.setTopAnchor(n, 0.0);
            AnchorPane.setRightAnchor(n, 0.0);
            AnchorPane.setLeftAnchor(n, 0.0);
            AnchorPane.setBottomAnchor(n, 0.0);
            custAcctPane.getChildren().setAll(n);
        } 
        catch (IOException e){
            System.out.println(e.getMessage());
        }
    }

    @FXML
    public void handleCreateCCMISelected(ActionEvent event) {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/View/CreateCreditCard.fxml"));
        
        try {
            Node n = (Node)loader.load();
            AnchorPane.setTopAnchor(n, 0.0);
            AnchorPane.setRightAnchor(n, 0.0);
            AnchorPane.setLeftAnchor(n, 0.0);
            AnchorPane.setBottomAnchor(n, 0.0);
            custAcctPane.getChildren().setAll(n);
        } 
        catch (IOException e){
            System.out.println(e.getMessage());
        }
    }  
    
    @FXML
    public void handleDisplayLoanMISelected(ActionEvent event) {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/View/Loans.fxml"));
        
        try {
            Node n = (Node)loader.load();
            AnchorPane.setTopAnchor(n, 0.0);
            AnchorPane.setRightAnchor(n, 0.0);
            AnchorPane.setLeftAnchor(n, 0.0);
            AnchorPane.setBottomAnchor(n, 0.0);
            custAcctPane.getChildren().setAll(n);
        } 
        catch (IOException e){
            System.out.println(e.getMessage());
        }
    }
    
    @FXML
    public void handleCreateLoanMISelected(ActionEvent event) {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/View/CreateLoan.fxml"));
        
        try {
            Node n = (Node)loader.load();
            AnchorPane.setTopAnchor(n, 0.0);
            AnchorPane.setRightAnchor(n, 0.0);
            AnchorPane.setLeftAnchor(n, 0.0);
            AnchorPane.setBottomAnchor(n, 0.0);
            custAcctPane.getChildren().setAll(n);
        } 
        catch (IOException e){
            System.out.println(e.getMessage());
        }
    }

    @FXML
    public void handleLogoutBtnClicked(ActionEvent event) {
        try { 
            Stage lastStage = (Stage) logoutBtn.getScene().getWindow();
            lastStage.close();
            Stage stage = new Stage();
            Pane root = FXMLLoader.load(getClass().getResource("/View/BankLogin.fxml")); 
            stage.getIcons().add(new Image("/View/path_logo.png"));
            stage.setTitle("Trail Bank");
            stage.setScene(new Scene(root, 600, 400));
            stage.setResizable(false);
            stage.sizeToScene();
            stage.show();          
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }
      
    @FXML
    public void handleSettingsBtnClicked(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/View/Settings.fxml"));
        
        try {
            Node n = (Node)loader.load();
            AnchorPane.setTopAnchor(n, 0.0);
            AnchorPane.setRightAnchor(n, 0.0);
            AnchorPane.setLeftAnchor(n, 0.0);
            AnchorPane.setBottomAnchor(n, 0.0);
            custAcctPane.getChildren().setAll(n);
        } 
        catch (IOException e){
            System.out.println(e.getMessage());
        }
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
