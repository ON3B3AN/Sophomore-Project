package Controller;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXPasswordField;
import com.jfoenix.controls.JFXRadioButton;
import com.jfoenix.controls.JFXTextField;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.layout.AnchorPane;


public class CreateAcctController implements Initializable {

    @FXML
    private JFXRadioButton maleRadioBtn;

    @FXML
    private JFXTextField zipcode;

    @FXML
    private JFXTextField firstName;

    @FXML
    private JFXPasswordField pin;

    @FXML
    private JFXTextField street;

    @FXML
    private JFXTextField DOB;

    @FXML
    private JFXTextField contactNumber;
    
    @FXML
    private JFXTextField lastName;

    @FXML
    private JFXTextField country;

    @FXML
    private JFXRadioButton custRadioBtn;

    @FXML
    private JFXRadioButton empRadioBtn;

    @FXML
    private JFXTextField city;
    
    @FXML
    private JFXTextField middleName;

    @FXML
    private JFXTextField state;

    @FXML
    private JFXPasswordField pwd;

    @FXML
    private JFXRadioButton femaleRadioBtn;

    @FXML
    private JFXTextField email;
    
    @FXML
    private AnchorPane createAcctPane;
    
    @FXML
    private JFXButton createBtn;
    
    @FXML
    private JFXButton backBtn;
    
    @FXML
    private Label pinLabel;
    
    
    @FXML
    public void handleFemaleRadioBtnSelected(ActionEvent event) {
        if(femaleRadioBtn.isSelected()) {
            maleRadioBtn.setSelected(false);
        }
        else
            maleRadioBtn.setSelected(true);
    }
    
    @FXML
    void handleMaleRadioBtnSelected(ActionEvent event) {
        if(maleRadioBtn.isSelected()) {
            femaleRadioBtn.setSelected(false);
        }
        else
            femaleRadioBtn.setSelected(true);
    }
    
    @FXML
    public void handleCustRadioBtnSelected(ActionEvent event) {
        if(custRadioBtn.isSelected()) {
            empRadioBtn.setSelected(false);
            pin.setVisible(true);
            pinLabel.setVisible(true);
        }
        else {
            empRadioBtn.setSelected(true);
            pin.clear();
            pin.setVisible(false);
            pinLabel.setVisible(false);
        }
    }
    
    @FXML
    void handleEmpRadioBtnSelected(ActionEvent event) {
        if(empRadioBtn.isSelected()) {
            custRadioBtn.setSelected(false);
            pin.clear();
            pin.setVisible(false);
            pinLabel.setVisible(false);
        }
        else {
            custRadioBtn.setSelected(true);
            pin.setVisible(true);
            pinLabel.setVisible(true);
        }
    }
    
    @FXML
    public void handleBackBtnClicked(ActionEvent event) throws IOException {
        AnchorPane pane = FXMLLoader.load(getClass().getResource("/View/BankLogin.fxml"));
        createAcctPane.getChildren().setAll(pane);
    }
    
    @FXML
    void handleCreateAcctClicked(ActionEvent event) throws IOException {
        System.out.println("Customer Account: " + custRadioBtn.isSelected());
        System.out.println("Employee Account: " + empRadioBtn.isSelected());
        System.out.println("First name: " + firstName.getText());
        System.out.println("Middle name: " + middleName.getText());
        System.out.println("Last name: " + lastName.getText());
        System.out.println("Street: " + street.getText());
        System.out.println("City: " + city.getText());
        System.out.println("State: " + state.getText());
        System.out.println("Country: " + country.getText());
        System.out.println("Zipcode: " + zipcode.getText());
        System.out.println("Male: " + maleRadioBtn.isSelected());
        System.out.println("Female: " + femaleRadioBtn.isSelected());
        System.out.println("DOB: " + DOB.getText());
        System.out.println("Contact Number: " + contactNumber.getText());
        System.out.println("Email: " + email.getText());
        System.out.println("Password: " + pwd.getText());
        System.out.println("PIN: " + pin.getText());
        
        AnchorPane pane = FXMLLoader.load(getClass().getResource("/View/BankLogin.fxml"));
        createAcctPane.getChildren().setAll(pane);
    }
    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
