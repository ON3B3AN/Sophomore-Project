package Controller;

import com.jfoenix.controls.JFXTextField;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;


public class LoansController implements Initializable {

    @FXML
    private JFXTextField houseAmt;

    @FXML
    private JFXTextField carInt;

    @FXML
    private JFXTextField schollInt;

    @FXML
    private JFXTextField schoolAmt;

    @FXML
    private JFXTextField houseInt;

    @FXML
    private JFXTextField carAmt;
       

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
