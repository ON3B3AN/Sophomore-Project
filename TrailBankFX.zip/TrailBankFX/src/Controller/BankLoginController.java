package Controller; 

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXCheckBox;
import com.jfoenix.controls.JFXComboBox;
import com.jfoenix.controls.JFXPasswordField;
import com.jfoenix.controls.JFXTextField;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import javax.swing.JOptionPane;

        
public class BankLoginController implements Initializable {
       
    @FXML
    private JFXComboBox<String> acctType;
    
    @FXML
    private AnchorPane rootPane;
    
    @FXML
    private AnchorPane forgotPwdPane;
    
    @FXML
    private JFXButton forgotPwd;

    @FXML
    private JFXButton empPortal;
    
    @FXML
    private JFXCheckBox rmbMe;
    
    @FXML
    private JFXButton createAcct;
    
    @FXML
    private JFXButton loginBtn;
    
    @FXML
    private JFXPasswordField pwd;

    @FXML
    private JFXTextField email;
    
    @FXML
    public void handleAcctType(ActionEvent event) {
        this.acctType.setPromptText(acctType.getValue());
    }
    
    @FXML
    public void handleForgotPwdClicked(ActionEvent event) throws IOException {
        AnchorPane pane = FXMLLoader.load(getClass().getResource("/View/ForgotPwd.fxml"));
        rootPane.getChildren().setAll(pane);
    }

    @FXML
    public void handleCreateAcctClicked(ActionEvent event) throws IOException {
        AnchorPane pane = FXMLLoader.load(getClass().getResource("/View/CreateAcct.fxml"));
        rootPane.getChildren().setAll(pane);
    }
    
    @FXML
    public void loginButtonClicked(ActionEvent event) {
        System.out.println("User logged in...");  
        System.out.println("Email = " + email.getText() + "\n" + "Password = " + pwd.getText());
        System.out.println("Remember Me = " + rmbMe.isSelected());  
        System.out.println("Account Type = " + acctType.getValue());
        email.setText(null);
        pwd.setText(null);
        rmbMe.setSelected(false);
        
        try { 
            if("Employee Account".equals(acctType.getValue())) {
                Stage lastStage = (Stage) loginBtn.getScene().getWindow();
                lastStage.close();
                Stage stage = new Stage();
                FXMLLoader loader = new FXMLLoader();
                Pane root = loader.load(getClass().getResource("/View/EmployeeAcct.fxml").openStream());
                stage.setScene(new Scene(root));
                //stage.setFullScreen(true);
                stage.setMaximized(true);
                stage.setTitle("Employee Account");
                stage.getIcons().add(new Image("/View/path_logo.png"));
                stage.showAndWait();   
            }
            else if("Customer Account".equals(acctType.getValue())) {
                Stage lastStage = (Stage) loginBtn.getScene().getWindow();
                lastStage.close();
                Stage stage = new Stage();
                FXMLLoader loader = new FXMLLoader();
                Pane root = loader.load(getClass().getResource("/View/CustomerAcct.fxml").openStream());
                stage.setScene(new Scene(root));
                //stage.setFullScreen(true);
                stage.setMaximized(true);
                stage.setTitle("Customer Account");
                stage.getIcons().add(new Image("/View/path_logo.png"));
                stage.showAndWait(); 
            }
            else {
                JOptionPane.showMessageDialog(null, "Please select an account type");
            }
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }
    
      
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        acctType.getItems().addAll("Employee Account","Customer Account");
    }
}
