package Controller;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXComboBox;
import com.jfoenix.controls.JFXTextField;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.layout.AnchorPane;
import javax.swing.JOptionPane;


public class ForgotPwdController implements Initializable {

    @FXML
    private JFXTextField email;
    
    @FXML
    private JFXTextField DOB;
    
    @FXML
    private JFXButton backBtn;
    
    @FXML
    private AnchorPane forgotPwdPane;
    
    @FXML
    private JFXComboBox<String> acctType;
    
    @FXML
    private JFXButton resetPwdBtn;

    
    @FXML
    public void handleBackBtnClicked(ActionEvent event) throws IOException {
        AnchorPane pane = FXMLLoader.load(getClass().getResource("/View/BankLogin.fxml"));
        forgotPwdPane.getChildren().setAll(pane);
    }
    
    
    @FXML
    public void handleAcctType(ActionEvent event) {
        this.acctType.setPromptText(acctType.getValue());
    }
       
    @FXML
    void handleResetPwdBtnClicked(ActionEvent event) throws IOException {
        System.out.println("Account type: " + acctType.getValue());
        System.out.println("email: " + email.getText());
        System.out.println("DOB: " + DOB.getText());
        AnchorPane pane = FXMLLoader.load(getClass().getResource("/View/BankLogin.fxml"));
        forgotPwdPane.getChildren().setAll(pane);
    }
    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        acctType.getItems().addAll("Employee Account","Customer Account");
    }    
    
}
